import webpack from 'webpack';
import webpackConfig from '../webpack.config.prod';
let colors = require('colors');

process.env.NODE_ENV = 'production';
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
console.log('generating minified bundle for production via webpack. This will take a moment..'.blue);

webpack(webpackConfig).run((err,stats)=>{
  if(err){
      console.log(err.bold.red);
      return 1;
  }

  const jsonStats = stats.toJson();

  if(jsonStats.hasErrors){
      return jsonStats.errors.map(error => console.log(err));
  }

  if(jsonStats.hasWarnings){
      console.log('webpack generated the following warnings: '.bold.yellow);
      jsonStats.warnings.map(warning=>console.log(warning.yellow))
  }
   console.log(`Webpack stats: $(stats)`);

  console.log('you app has been compile and written to /dist'.green);

  return 0;
});

let colors = require('colors');

/* eslint-disable no-console */

console.log('Starting app in dev mode...'.green);

import webpack from 'webpack';
import path from 'path';
import ExtractTextPlugin from 'extract-text-webpack-plugin';
const MinifyPlugin = require('uglifyjs-webpack-plugin');
const CompressionPlugin = require('compression-webpack-plugin')
const GLOBALS = {
    'process.env.NODE_ENV':JSON.stringify('production')
};
export default {
    entry: './src/index',
    target: 'web',
    output: {
        path: __dirname + '/dist', // Note: Physical files are only output by the production build task `npm run build`.
        publicPath: '/',
        filename: 'bundle.js'
    },
    devServer: {
        contentBase: './dist'
    },
    plugins: [
      new webpack.DefinePlugin({
        'process.env':{
          NODE_ENV:JSON.stringify('production')
        }
      }),
      new webpack.IgnorePlugin(/^\.\/locale$/,/moment$/),
      new MinifyPlugin({
        sourceMap:false,
        cache:true,
        parallel:true
      }),
      new CompressionPlugin({
        cache:true
      })
  ],
    resolve:{
      extensions: ['.js','.jsx']
    },
    module: {
        loaders: [

            {
                exclude: path.resolve(__dirname, 'node_modules'),
                loader: 'babel-loader',
                query: {
                    presets: ['react','es2015', 'stage-2','stage-0']
                }
            },
            {
                exclude: path.resolve(__dirname, 'node_modules'),
                test: /\.json$/,
                loader: 'raw-loader'
            },
            {
                exclude: path.resolve(__dirname, 'node_modules'),
                test: /\.js$/,
                loader: 'babel-loader'
            },
            {
                test: /\.css$/,
                loaders: ['style-loader', 'css-loader']
            },
            {
                test: /\.(png|jpg|gif)(\?v=\d+\.\d+\.\d+)?$/,
                loader: 'url-loader?limit=100000'
            },
            {
                test: /\.(eot|com|json|ttf|woff|woff2)(\?v=\d+\.\d+\.\d+)?$/,
                loader: 'url-loader?limit=10000&mimetype=application/octet-stream'
            },
            {test: /\.ico$/, loader: 'file-loader?name=[name].[ext]'},
            {
                test: /\.svg(\?v=\d+\.\d+\.\d+)?$/,
                loader: 'url-loader?limit=10000&mimetype=image/svg+xml'
            }
        ]
    }

};

export const SET_CURRENCY = "SET_CURRENCY";
export const TEXT_VAL = "TEXT_VAL";
export const ERROR = "ERROR";
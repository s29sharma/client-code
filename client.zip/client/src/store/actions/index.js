import * as constants from './constants';
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
const SERVER_URL = "http://localhost:8080";

export const sendForConversion = (amount) => async dispatch => {
    try {
        await fetch(`${SERVER_URL}/api/v1/convert`, {
            method: 'POST',
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*",
                "Accept": "application/json",
            },
            body: JSON.stringify({
                Amount: amount
            })
        }).then(message => message.json())
            .then(res => {
                    dispatch({type: constants.SET_CURRENCY, payload: res.amount});
            });
    }
    catch (error) {
        dispatch({type: constants.ERROR, payload: true});
    }
};

export const updateTextBox = (val) => async dispatch =>{
    try{
        dispatch({
            type:constants.TEXT_VAL,
            payload:val
        })
    }
    catch (error) {
        dispatch({type: constants.ERROR, payload: true});
    }
};


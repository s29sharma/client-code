//specifying the reducers for the page
import {handleAction} from 'redux-actions';
import * as constants from '../actions/constants'


export const CONVERSION = handleAction(
  constants.SET_CURRENCY,(state,action) => action.payload !=="undefined" ?
    state = action.payload : state ,{});

export const TEXT_VAL = handleAction(
    constants.TEXT_VAL,(state,action) => action.payload !=="undefined" ?
        state = action.payload : state ,{});

export const ERROR = handleAction(
    constants.ERROR,(state,action) => action.payload !=="undefined" ?
        state = action.payload : state ,false);


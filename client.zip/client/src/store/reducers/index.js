import {combineReducers} from 'redux';
import {CONVERSION,ERROR,TEXT_VAL
} from "./reducers";

const rootReducer = combineReducers({
    CONVERSION,ERROR,TEXT_VAL
});

export default rootReducer;

import React, {Component} from 'react';
import {InputGroupAddon,InputGroup,Input} from 'reactstrap';
import './styles.css'
import {connect} from "react-redux";
import {bindActionCreators} from "redux";
import {sendForConversion,updateTextBox} from '../../store/actions/index'
class AmountArtifact extends Component{
    constructor(props){
        super(props);
        this.state={
            amount:''
        };
        this.handleButtonClick = this.handleButtonClick.bind(this);
        this.handleInputChange = this.handleInputChange.bind(this);
        this.convert = this.convert.bind(this);
    }
    componentDidMount() {
        this.interval = setInterval(() => this.convert(), 100);
    }
    componentWillUnmount() {
        clearInterval(this.interval);
    }
    handleButtonClick(){
        this.setState({
            amount:''
        })
    }

    async convert(){
        let AMOUNT_VAL = this.state.amount;
        if(AMOUNT_VAL !==undefined && AMOUNT_VAL!=="" && AMOUNT_VAL !== "0"){
            await this.props.sendForConversion(parseFloat(this.state.amount));
            await this.props.updateTextBox(this.props.CONVERSION)
        }
        else{
            await this.props.updateTextBox("0")
        }
    }

    async handleInputChange(event){
        await this.setState({
            amount: event.target.value
        });
        this.convert();
    }
    render() {
        return (
            <InputGroup>
                <Input type="number"
                       value={this.state.amount}
                       onChange={(event)=>this.handleInputChange(event)}
                       name="amount" id="amount"
                       placeholder="Enter Amount"/>
                <InputGroupAddon
                    onClick={this.handleButtonClick}
                    className="add-on-input" addonType="append">x</InputGroupAddon>
            </InputGroup>
        )
    }
}
function mapStateToProps(state) {
    return { CONVERSION: state.CONVERSION};
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators({sendForConversion,updateTextBox}, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(AmountArtifact);
import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import {connect} from 'react-redux';
const currencyTypes = ["CAD", "GBP", "EUR"];
import {Col, FormGroup, Label, Input} from 'reactstrap';
import AmountArtifact from '../AmountArtifact/index'
import {sendForConversion} from '../../store/actions/index'
const bottomText={
    marginTop:'20px'
};
class Converter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            result:''
        };
    }


    render() {
        return (
            <div>
                <Col className="container">
                    <Col className="row">
                        <Col className="col-sm-3">
                            <FormGroup>
                                <Label for="currency">Select a currency:</Label>
                                <Input type="select" name="currency" id="currency">
                                    {currencyTypes.map((type,i)=>
                                        <option key={i}>{type}</option>
                                    )}
                                </Input>
                            </FormGroup>

                            <AmountArtifact/>

                            <Input
                                style={bottomText}
                                type="number"
                                   value={this.props.TEXT_VAL}
                                   disabled={true}
                                   name="result" id="result"
                                   placeholder=""/>
                        </Col>
                    </Col>
                </Col>
            </div>
        )
    }
}

function mapStateToProps(state) {
    return {
        TEXT_VAL: state.TEXT_VAL
    };
}

function mapDispatchToProps(dispatch) {
    return bindActionCreators({sendForConversion}, dispatch);
}

export default connect(mapStateToProps, mapDispatchToProps)(Converter);
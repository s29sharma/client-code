import React from 'react';
import 'babel-polyfill';
import ReactDOM from 'react-dom';
import {Switch} from 'react-router';
import {Provider} from 'react-redux'
import {BrowserRouter, Route} from 'react-router-dom'
import configureStore from './store/configureStore'
import {register} from './serviceWorker';
import '.././node_modules/bootstrap/dist/css/bootstrap.min.css'
const store = configureStore();
import Converter from './components/Converter/index'

store.subscribe(()=>{
  console.log(store.getState())
});


ReactDOM.render((
    <Provider store={store}>
        <BrowserRouter>
            <Switch>
                <Route exact path="/" component={Converter}/>
            </Switch>
        </BrowserRouter>
    </Provider>
), document.getElementById('app'));
register();

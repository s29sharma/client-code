package com.sachinsharma.controllers;
import java.util.Random;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class converter {
	/*
	 * Creating objects of random class(a utility class provided by java) 
	 * and currency class
	 *  
	 *  */
	Random myRandom = new Random();
	currency currency = new currency();
	/*
	 * Declaring final upper and lower bounds for random number to be generated.
	 * Declaring amt and transaction variables and leaving them uninitialized
	 * */
	final int minRandom = 0;
	final int maxRandom = 1;
	Double amt;
	Double transaction;
	
	/*
	 * Declaring the API end point which receives data of format application/json
	 * and sends a response back a currency POJO in the same format
	 * 
	 * */
    @CrossOrigin(origins = "http://localhost:3005")
	@PostMapping(value= "/api/v1/convert",consumes = "application/json", produces = "application/json")
	ResponseEntity<?>convert(@RequestBody currency data) throws NumberFormatException{
		// Retrieving amount sent as JSON by using getter method
    		//System.out.println(data);
		amt = data.Amount;
		//Calculating transaction
		transaction = (amt * 2) +(Math.random() * ((maxRandom - minRandom)));
		//using setter to manipulate currency object
		currency.setAmount(transaction);
		//sending  a valid JSON
		return new ResponseEntity<currency>(currency,HttpStatus.OK);
	}
}

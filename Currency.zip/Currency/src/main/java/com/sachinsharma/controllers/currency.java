package com.sachinsharma.controllers;

/*
 * currency POJO class. 
 * We specify only one instance variable and the getters and setters for it
 * 
 */
public class currency {

	public Double Amount;

	public Double getAmount() {
		return Amount;
	}

	public void setAmount(Double Amount) {
		this.Amount = Amount;
	}
	
}
